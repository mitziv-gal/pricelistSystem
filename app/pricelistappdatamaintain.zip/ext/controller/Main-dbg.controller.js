sap.ui.define(
    [
        'sap/fe/core/PageController'
    ],
    function(Controller) {
        'use strict';

        return Controller.extend('pricelistapp.datamaintain.ext.controller.Main', {
            onRowPress: function (oEvent) {
                // 1. Get the context from the macro event parameters
                const oBindingContext = oEvent.getParameter("bindingContext");
                if (!oBindingContext) { return; }

                // 2. Access the data using getObject()
                const oContextData = oBindingContext.getObject();
                const sTableName = oContextData.tableName; 
                const sID = oContextData.ID; 
                
                // 3. Get the router from the PageController base
                const oRouter = this.getOwnerComponent().getRouter();

                let sRouteName = "";

                // Exact match for your HANA DB strings
                switch (sTableName) {
                    case "Trade Scenarios":
                        sRouteName = "TradeScenariosListPage";
                        break;
                    case "Item Structure":
                        sRouteName = "ItemStructureObjectPage";
                        break;
                    case "Part Numbers":
                        sRouteName = "PartNumberObjectPage";
                        break;
                    case "Terms & Conditions":
                        sRouteName = "TermsAndConditionsObjectPage";
                        break;
                    case "Pricing Parameters":
                        sRouteName = "PricingParametersObjectPage";
                        break;
                    case "Information Tiles":
                        sRouteName = "TileContentObjectPage";
                        break;
                    case "Contact Info":
                        sRouteName = "ContactInfoObjectPage";
                        break;
                }

                if (sRouteName) {
                    this.getExtensionAPI().getRouting().navigateToRoute(sRouteName, 
                        { 
                            
                        }
                    );

                }
            },

            onNavBack: function () {
                this.getOwnerComponent().getRouter().navTo("TableDirectoryList", {}, true);
            },

            onEditAction: function (oEvent) {
                debugger;
                const oContext = oEvent.getSource().getBindingContext();
            }
        });
    }
);
