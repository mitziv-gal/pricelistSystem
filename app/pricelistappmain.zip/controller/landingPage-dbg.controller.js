sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/format/DateFormat"
], function (Controller, MessageToast, JSONModel, DateFormat) {
    "use strict";

    return Controller.extend("pricelistapp.main.controller.landingPage", {
        onInit: function () {
            //Create a JSON Model to hold display data.
            var oViewModel = new JSONModel({
                currentDate: new Date(),
                userName: "" // Default placeholder
            });

            //Set the model to the view with the name "home".
            this.getView().setModel(oViewModel, "home");

            //Calculate the formatted date (e.g., "Wednesday, December 10, 2025").
            this._setFormattedDate(oViewModel);

            //Fetch real user name if running in Fiori Launchpad.
            this._setUserName(oViewModel);
        },

        _setFormattedDate: function (oModel) {
            var oDate = new Date();
            var oOptions = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };

            // Result: "Wednesday, December 10, 2025"
            var sFormattedDate = oDate.toLocaleDateString('en-US', oOptions);

            oModel.setProperty("/currentDate", sFormattedDate);
        },

        _setUserName: function (oModel) {
            if (sap.ushell && sap.ushell.Container) {
                var oUser = sap.ushell.Container.getUser();
                var sFullName = oUser.getFullName(); //oUser.getId()
                oModel.setProperty("/userName", sFullName);
            }
        },

        onPressTile: function (oEvent) {
            // Get the control that was clicked.
            var oTile = oEvent.getSource();

            // Read the Custom Data key 'target' (e.g., "SalesOrder-display")
            var sTargetIntent = oTile.data("target");

            if (!sTargetIntent) {
                MessageToast.show("No target defined for this tile.");
                return;
            }

            // Split the intent into Semantic Object and Action - Expecting format "Object-action"
            var aParts = sTargetIntent.split("-");
            var sSemanticObject = aParts[0];
            var sAction = aParts[1];

            /* // Get the CrossApplicationNavigation Service
            // This service only exists if running inside Fiori Launchpad (or FLP Sandbox).
            var oCrossAppNavigator = sap.ushell && sap.ushell.Container &&
                sap.ushell.Container.getService("CrossApplicationNavigation");

            if (oCrossAppNavigator) {
                // Trigger the navigation.
                oCrossAppNavigator.toExternal({
                    target: {
                        semanticObject: sSemanticObject,
                        action: sAction
                    }
                });
            } else {
                // Fallback for local testing without FLP sandbox.
                MessageToast.show("Navigation triggered: " + sTargetIntent);
                console.log("Navigating to:", sSemanticObject, sAction);

            } */

            /* // --- EMERGENCY FALLBACK FOR LOCAL TESTING ---
            // If the shell fails or is missing, jump to the folder path directly
            if (sTargetIntent === "PriceMaintain-manage") {
                // Adjust this path based on your 'cds watch' output
                window.location.href = "/pricemaintain/index.html";
            } */

            // Get the CrossApplicationNavigation service
            sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oCrossAppNavigator) {
                // Define the navigation target
                var oTarget = {
                    target: {
                        semanticObject: sSemanticObject,
                        action: sAction
                    }
                };

                // Navigate to the target app
                oCrossAppNavigator.toExternal(oTarget);
            }).catch(function (oError) {
                MessageToast.show("Navigation failed: " + oError.message);
            });

            
            if (!sap.ushell || !sap.ushell.Container) {
                // Base URL for local navigation
                const sBaseUrl = window.location.origin;
                switch (sTargetIntent) {
                    case "PriceMaintain-manage":
                        window.location.href = "/pricelistapp.main/index.html";
                        break;
                    case "DataMaintain-manage":
                        window.location.href = "/pricelistapp.datamaintenance/index.html";
                        break;
                    case "AppLog-display":
                        window.location.href = "/pricelistapp.applicationlog/index.html";
                        break;
                    default:
                        MessageToast.show("No navigation defined for: " + sTargetIntent);
                        break;
                }
                return;
            }
        },

        onNavigationAppPress: function (oEvent) {
            // Get the clicked tile and its target intent
            const oTile = oEvent.getSource();
            const sTargetIntent = oTile.data("target") || "";

            // Split semantic object and action safely
            const [sSemanticObject, sAction] = sTargetIntent.split("-");

            if (!sSemanticObject || !sAction) { return; }

            if (!sap.ushell || !sap.ushell.Container) {
                // Base URL for local navigation
                const sBaseUrl = window.location.origin;
                switch (sTargetIntent) {
                    case "PriceMaintain-manage":
                        window.location.href = "/priceListSystem/app/webapp/index.html";
                        break;
                    case "DataMaintain-manage":
                        window.location.href = "/priceListSystem/app/webapp/index.html";
                        break;
                    case "AppLog-display":
                        window.location.href = "/priceListSystem/app/webapp/index.html";
                        break;
                    default:
                        MessageToast.show("No navigation defined for: " + sTargetIntent);
                        break;
                }
                return;
            }

            // Get the CrossApplicationNavigation service
            sap.ushell.Container.getServiceAsync("CrossApplicationNavigation").then(function (oCrossAppNavigator) {
                // Define the navigation target
                var oTarget = {
                    target: {
                        semanticObject: sSemanticObject,
                        action: sAction
                    }
                };

                // Navigate to the target application
                oCrossAppNavigator.toExternal(oTarget);
            }).catch(function (oError) {
                MessageToast.show("Navigation failed: " + oError.message);
            });
        }
    });
});